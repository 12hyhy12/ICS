int isCache(char *host, char *port, char *path, int fd);

void initCache();

void addCache(char *host, char *port, char *path, char *buffer, int size);
